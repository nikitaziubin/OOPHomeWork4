﻿namespace Interface
{
    internal interface Interface1
    {
        public void getInformation(string name, int x, int y);
    }
}
