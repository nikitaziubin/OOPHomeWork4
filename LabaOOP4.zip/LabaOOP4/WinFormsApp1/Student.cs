﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class Student
    {        
        public string? faculty { get; set; }
        public string? kafedra { get; set; }
        public string? cours { get; set; }
        public string? livePlace { get; set; }
        public int id { get; set; }
      
    }
}
